package vista;

import controlador.IncidenciaControlador;

import java.util.Scanner;

public class MenuInformes {

    private final IncidenciaControlador controlador = new IncidenciaControlador();
    private final Scanner scanner = new Scanner(System.in);

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n--- Informes de Incidencias ---");
            System.out.println("1. Total de Incidencias por Empleado");
            System.out.println("2. Incidencias Abiertas por Prioridad");
            System.out.println("3. Tiempo promedio de resolución por Empleado");
            System.out.println("4. Volver al Menú Principal");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    controlador.informeTotalPorEmpleado();
                    break;
                case 2:
                    controlador.informeAbiertasPorPrioridad();
                    break;
                case 3:
                    controlador.informeTiempoResolucionPromedio();
                    break;
                case 4:
                    System.out.println("Volviendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }

        } while (opcion != 4);
    }
}

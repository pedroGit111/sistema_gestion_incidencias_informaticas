package vista;

import controlador.IncidenciaControlador;

import java.util.Scanner;

public class MenuIncidencias {

    private final IncidenciaControlador controlador = new IncidenciaControlador();
    private final Scanner scanner = new Scanner(System.in);

    public void mostrar() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Incidencias ---");
            System.out.println("1. Registrar Incidencia");
            System.out.println("2. Listar Todas");
            System.out.println("3. Cambiar Estado");
            System.out.println("4. Eliminar Incidencia");
            System.out.println("5. Volver");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    controlador.registrar();
                    break;
                case 2:
                    controlador.listar();
                    break;
                case 3:
                    controlador.cambiarEstado();
                    break;
                case 4:
                    controlador.eliminar();
                    break;
                case 5:
                    System.out.println("Volviendo...");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        } while (opcion != 5);
    }
}
package vista;

import controlador.EmpleadoControlador;
import controlador.IncidenciaControlador;

import java.util.Scanner;

public class MenuPrincipal {

    private final EmpleadoControlador empleadoControlador = new EmpleadoControlador();
    private final IncidenciaControlador incidenciaControlador = new IncidenciaControlador();
    private final Scanner scanner = new Scanner(System.in);

    public void mostrar() {
        int opcion;
        do {
            System.out.println("=== Menú Principal ===");
            System.out.println("1. Gestionar Empleados");
            System.out.println("2. Gestionar Incidencias");
            System.out.println("3. Ver Incidencias por Estado");
            System.out.println("4. Ver Historial de un Empleado");
            System.out.println("5. Ver Informes Generales");
            System.out.println("6. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    empleadoControlador.menuGestionEmpleados();
                break;
                case 2:
                    incidenciaControlador.menuGestionIncidencias();
                break;
                case 3:
                    incidenciaControlador.buscarPorEstado();
                break;
                case 4:
                    incidenciaControlador.verHistorialPorEmpleado();
                break;
                case 5:
                new MenuInformes().mostrar();
                break;
                case 6:
                    System.out.println("Cerrando sesión...");
                break;
                default:
                    System.out.println("Opción no válida.");
                break;
}

        } while (opcion != 6);
    }
}

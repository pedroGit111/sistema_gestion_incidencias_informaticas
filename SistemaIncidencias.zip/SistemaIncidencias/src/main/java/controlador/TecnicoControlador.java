package controlador;

import dao.TecnicoDAO;

import java.util.Scanner;

public class TecnicoControlador {

    private TecnicoDAO tecnicoDAO = new TecnicoDAO();
    private Scanner scanner = new Scanner(System.in);

    public boolean autenticar() {
        System.out.println("=== Sistema de Gestión de Incidencias ===");
        System.out.print("Ingrese su usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Ingrese su contraseña: ");
        String pass = scanner.nextLine();

        if (tecnicoDAO.autenticarTecnico(usuario, pass)) {
            System.out.println(" Autenticación exitosa.\n");
            return true;
        } else {
            System.out.println(" Usuario o contraseña incorrectos.\n");
            return false;
        }
    }
}

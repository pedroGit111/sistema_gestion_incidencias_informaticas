package controlador;

import dao.IncidenciaDAO;
import dao.ConexionBD;
import modelo.Incidencia;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class IncidenciaControlador {

    private IncidenciaDAO dao = new IncidenciaDAO();
    private Scanner scanner = new Scanner(System.in);

    public void menuGestionIncidencias() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Incidencias ---");
            System.out.println("1. Registrar Incidencia");
            System.out.println("2. Listar Todas");
            System.out.println("3. Cambiar Estado");
            System.out.println("4. Eliminar Incidencia");
            System.out.println("5. Volver");
            System.out.print("Opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    registrar();
                    break;
                case 2:
                    listar();
                    break;
                case 3:
                    cambiarEstado();
                    break;
                case 4:
                    eliminar();
                    break;
                case 5:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 5);
    }

    public void registrar() {
        System.out.print("ID del empleado: ");
        int idEmp = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Descripción: ");
        String desc = scanner.nextLine();
        if (dao.existeIncidenciaCerradaConMismaDescripcion(desc)) {
            System.out.println("Ya existe una incidencia cerrada con esa descripción. Registro denegado.");
            return;
        }
        System.out.print("Prioridad (Alta, Media, Baja): ");
        String prio = scanner.nextLine();
        System.out.print("Estado inicial (Abierta, En proceso): ");
        String estado = scanner.nextLine();

        dao.registrarIncidencia(new Incidencia(idEmp, desc, prio, estado, Date.valueOf(LocalDate.now())));
    }

    public void listar() {
        List<Incidencia> lista = dao.obtenerTodasLasIncidencias();
        for (Incidencia i : lista) {
            System.out.println("ID: " + i.getId() + " | Empleado ID: " + i.getIdEmpleado() +
                    " | Estado: " + i.getEstado() + " | Prioridad: " + i.getPrioridad() +
                    " | Fecha creación: " + i.getFechaCreacion() +
                    (i.getFechaResolucion() != null ? " | Resuelta: " + i.getFechaResolucion() : ""));
        }
    }

    public void cambiarEstado() {
        System.out.print("ID de la incidencia: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nuevo estado: ");
        String estado = scanner.nextLine();

        Date fechaResol = null;
        if (estado.equalsIgnoreCase("Cerrada")) {
            fechaResol = Date.valueOf(LocalDate.now());
        }

        dao.cambiarEstadoIncidencia(id, estado, fechaResol);
    }

    public void eliminar() {
        System.out.print("ID de la incidencia a eliminar: ");
        int id = scanner.nextInt();
        dao.eliminarIncidencia(id);
    }

    public void buscarPorEstado() {
        System.out.print("Ingrese el estado a buscar (Abierta, En proceso, Cerrada): ");
        String estado = scanner.nextLine();

        String sql = "SELECT i.id, e.nombre AS empleado, i.descripcion, i.prioridad, i.estado, i.fecha_creacion " +
                "FROM incidencias i JOIN empleados e ON i.id_empleado = e.id " +
                "WHERE i.estado = ?";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, estado);
            ResultSet rs = stmt.executeQuery();

            System.out.println("\n--- Incidencias en estado: " + estado + " ---");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                        " | Empleado: " + rs.getString("empleado") +
                        " | Descripción: " + rs.getString("descripcion") +
                        " | Prioridad: " + rs.getString("prioridad") +
                        " | Fecha: " + rs.getDate("fecha_creacion"));
            }

        } catch (SQLException e) {
            System.out.println("Error al buscar incidencias por estado: " + e.getMessage());
        }
    }

    public void verHistorialPorEmpleado() {
        System.out.print("Ingrese el ID del empleado: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        String sql = "SELECT * FROM incidencias WHERE id_empleado = ?";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            System.out.println("\n--- Historial de Incidencias del Empleado ID: " + id + " ---");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") +
                        " | Estado: " + rs.getString("estado") +
                        " | Descripción: " + rs.getString("descripcion") +
                        " | Prioridad: " + rs.getString("prioridad") +
                        " | Fecha creación: " + rs.getDate("fecha_creacion") +
                        " | Resolución: " + rs.getDate("fecha_resolucion"));
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener historial del empleado: " + e.getMessage());
        }
    }

    public void informeTotalPorEmpleado() {
        String sql = "SELECT e.nombre, " +
                "SUM(CASE WHEN i.estado = 'Abierta' THEN 1 ELSE 0 END) AS abiertas, " +
                "SUM(CASE WHEN i.estado = 'Cerrada' THEN 1 ELSE 0 END) AS cerradas " +
                "FROM empleados e LEFT JOIN incidencias i ON e.id = i.id_empleado " +
                "GROUP BY e.nombre";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n--- Total de Incidencias por Empleado ---");
            while (rs.next()) {
                System.out.println("Empleado: " + rs.getString("nombre") +
                        " - Abiertas: " + rs.getInt("abiertas") +
                        " - Cerradas: " + rs.getInt("cerradas"));
            }

        } catch (SQLException e) {
            System.out.println("Error en informe de incidencias por empleado: " + e.getMessage());
        }
    }

    public void informeAbiertasPorPrioridad() {
        String sql = "SELECT prioridad, COUNT(*) AS cantidad " +
                "FROM incidencias WHERE estado = 'Abierta' GROUP BY prioridad";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n--- Incidencias Abiertas por Prioridad ---");
            while (rs.next()) {
                System.out.println("Prioridad " + rs.getString("prioridad") +
                        ": " + rs.getInt("cantidad") + " incidencias");
            }

        } catch (SQLException e) {
            System.out.println("Error en informe de prioridad: " + e.getMessage());
        }
    }

    public void informeTiempoResolucionPromedio() {
        String sql = "SELECT e.nombre, " +
                "AVG(DATEDIFF(i.fecha_resolucion, i.fecha_creacion)) AS promedio_dias " +
                "FROM incidencias i JOIN empleados e ON i.id_empleado = e.id " +
                "WHERE i.fecha_resolucion IS NOT NULL " +
                "GROUP BY e.nombre";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            System.out.println("\n--- Tiempo Promedio de Resolución por Empleado ---");
            while (rs.next()) {
                System.out.println("Empleado: " + rs.getString("nombre") +
                        " - Tiempo promedio: " + String.format("%.2f", rs.getDouble("promedio_dias")) + " días");
            }

        } catch (SQLException e) {
            System.out.println("Error en informe de tiempo promedio: " + e.getMessage());
        }
    }
}
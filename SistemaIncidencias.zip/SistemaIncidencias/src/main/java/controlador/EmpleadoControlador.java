package controlador;

import dao.EmpleadoDAO;
import modelo.Empleado;
import util.Validaciones;

import java.util.List;
import java.util.Scanner;

public class EmpleadoControlador {

    private EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    private Scanner scanner = new Scanner(System.in);

    public void menuGestionEmpleados() {
        int opcion;
        do {
            System.out.println("\n--- Gestión de Empleados ---");
            System.out.println("1. Listar Empleados");
            System.out.println("2. Añadir Empleado");
            System.out.println("3. Actualizar Empleado");
            System.out.println("4. Eliminar Empleado");
            System.out.println("5. Volver");
            System.out.print("Opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    listarEmpleados();
                    break;
                case 2:
                    añadirEmpleado();
                    break;
                case 3:
                    actualizarEmpleado();
                    break;
                case 4:
                    eliminarEmpleado();
                    break;
                case 5:
                    System.out.println("Volviendo al menú principal...");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 5);
    }

    private void listarEmpleados() {
        List<Empleado> empleados = empleadoDAO.obtenerTodosLosEmpleados();
        for (Empleado e : empleados) {
            System.out.println("ID: " + e.getId() + ", Nombre: " + e.getNombre() + ", Email: " + e.getEmail());
        }
    }

    private void añadirEmpleado() {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        if (!Validaciones.esEmailValido(email)) {
            System.out.println(" Email no válido.");
            return;
        }

        empleadoDAO.insertarEmpleado(new Empleado(nombre, email));
        System.out.println("Empleado añadido correctamente.");
    }

    private void actualizarEmpleado() {
        System.out.print("ID del empleado a actualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Nuevo nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Nuevo email: ");
        String email = scanner.nextLine();

        if (!Validaciones.esEmailValido(email)) {
            System.out.println(" Email no válido.");
            return;
        }

        empleadoDAO.actualizarEmpleado(new Empleado(id, nombre, email));
        System.out.println("Empleado actualizado correctamente.");
    }

    private void eliminarEmpleado() {
        System.out.print("ID del empleado a eliminar: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        empleadoDAO.eliminarEmpleado(id);
        System.out.println("Empleado eliminado correctamente.");
    }
}
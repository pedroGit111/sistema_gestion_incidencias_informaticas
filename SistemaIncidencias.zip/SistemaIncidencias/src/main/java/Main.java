import controlador.EmpleadoControlador;
import controlador.IncidenciaControlador;
import controlador.TecnicoControlador;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        TecnicoControlador tecnicoControlador = new TecnicoControlador();
        EmpleadoControlador empleadoControlador = new EmpleadoControlador();
        IncidenciaControlador incidenciaControlador = new IncidenciaControlador();
        Scanner scanner = new Scanner(System.in);

        boolean sesionActiva = tecnicoControlador.autenticar();

        while (sesionActiva) {
            System.out.println("=== Menú Principal ===");
            System.out.println("1. Gestionar Empleados");
            System.out.println("2. Gestionar Incidencias");
            System.out.println("3. Ver Incidencias por Estado (pendiente)");
            System.out.println("4. Ver Historial de un Empleado (pendiente)");
            System.out.println("5. Ver Informes Generales (pendiente)");
            System.out.println("6. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

          switch (opcion) {
            case 1:
                empleadoControlador.menuGestionEmpleados();
            break;
            case 2:
                incidenciaControlador.menuGestionIncidencias();
            break;
            case 3:
            case 4:
            case 5:
                System.out.println("Funcionalidad aún no implementada.");
            break;
            case 6:
                System.out.println("Cerrando sesión...");
                sesionActiva = false;
            break;
            default:
                System.out.println("Opción no válida.");
            break;
}
        }

        System.out.println("Aplicación finalizada.");
    }
}

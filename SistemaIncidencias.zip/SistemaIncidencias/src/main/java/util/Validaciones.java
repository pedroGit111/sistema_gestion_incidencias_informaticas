package util;

import java.util.regex.Pattern;

public class Validaciones {

    private static final Pattern EMAIL_PATTERN =
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");

    public static boolean esEmailValido(String email) {
        return EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean esPrioridadValida(String prioridad) {
        return prioridad.equalsIgnoreCase("Alta") ||
               prioridad.equalsIgnoreCase("Media") ||
               prioridad.equalsIgnoreCase("Baja");
    }

    public static boolean esEstadoValido(String estado) {
        return estado.equalsIgnoreCase("Abierta") ||
               estado.equalsIgnoreCase("En proceso") ||
               estado.equalsIgnoreCase("Cerrada");
    }

    public static boolean esTextoNoVacio(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }
}

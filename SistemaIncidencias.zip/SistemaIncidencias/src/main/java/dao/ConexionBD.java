package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {

    private static final String URL = "jdbc:mysql://localhost:3306/sistema_incidencias";
    private static final String USUARIO = "MySQL93"; // Cambia si usas otro usuario
    private static final String CONTRASENA = "root"; // Cambia si tienes otra contraseña

    public static Connection obtenerConexion() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, CONTRASENA);
    }

}

package dao;

import modelo.Tecnico;
import java.sql.*;

public class TecnicoDAO {

    public boolean autenticarTecnico(String usuario, String password) {
        String sql = "SELECT * FROM tecnicos WHERE nombre_usuario = ? AND password = ?";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();
            return rs.next(); // Si hay resultado, la autenticación fue exitosa

        } catch (SQLException e) {
            System.out.println("Error al autenticar técnico: " + e.getMessage());
            return false;
        }
    }

    public void registrarTecnico(Tecnico tecnico) {
        String sql = "INSERT INTO tecnicos (nombre_usuario, password) VALUES (?, ?)";
        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, tecnico.getNombreUsuario());
            stmt.setString(2, tecnico.getPassword());
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al registrar técnico: " + e.getMessage());
        }
    }
}

package dao;

import modelo.Incidencia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class IncidenciaDAO {

    public void registrarIncidencia(Incidencia incidencia) {
        String sql = "INSERT INTO incidencias (id_empleado, descripcion, prioridad, estado, fecha_creacion) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, incidencia.getIdEmpleado());
            stmt.setString(2, incidencia.getDescripcion());
            stmt.setString(3, incidencia.getPrioridad());
            stmt.setString(4, incidencia.getEstado());
            stmt.setDate(5, incidencia.getFechaCreacion());
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al registrar incidencia: " + e.getMessage());
        }
    }

    public List<Incidencia> obtenerTodasLasIncidencias() {
        List<Incidencia> lista = new ArrayList<>();
        String sql = "SELECT * FROM incidencias";

        try (Connection conn = ConexionBD.obtenerConexion();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Incidencia inc = new Incidencia(
                        rs.getInt("id"),
                        rs.getInt("id_empleado"),
                        rs.getString("descripcion"),
                        rs.getString("prioridad"),
                        rs.getString("estado"),
                        rs.getDate("fecha_creacion"),
                        rs.getDate("fecha_resolucion")
                );
                lista.add(inc);
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener incidencias: " + e.getMessage());
        }

        return lista;
    }

    public void cambiarEstadoIncidencia(int idIncidencia, String nuevoEstado, Date fechaResolucion) {
        String sql = "UPDATE incidencias SET estado = ?, fecha_resolucion = ? WHERE id = ?";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nuevoEstado);
            stmt.setDate(2, fechaResolucion);
            stmt.setInt(3, idIncidencia);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al cambiar estado de la incidencia: " + e.getMessage());
        }
    }

    public void eliminarIncidencia(int id) {
        String sql = "DELETE FROM incidencias WHERE id = ?";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println("Error al eliminar incidencia: " + e.getMessage());
        }
    }

    public boolean existeIncidenciaCerradaConMismaDescripcion(String descripcion) {
        String sql = "SELECT COUNT(*) FROM incidencias WHERE descripcion = ? AND estado = 'Cerrada'";

        try (Connection conn = ConexionBD.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, descripcion);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }

        } catch (SQLException e) {
            System.out.println("Error al verificar descripción duplicada: " + e.getMessage());
        }

        return false;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemaincidencias;

/**
 *
 * @author Usuario
 */
public class SistemaIncidencias {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}

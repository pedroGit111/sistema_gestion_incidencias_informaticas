package modelo;

import java.sql.Date;

public class Incidencia {
    private int id;
    private int idEmpleado;
    private String descripcion;
    private String prioridad;
    private String estado;
    private Date fechaCreacion;
    private Date fechaResolucion;

    // Constructor vacío
    public Incidencia() {
    }

    // Constructor completo
    public Incidencia(int id, int idEmpleado, String descripcion, String prioridad, String estado, Date fechaCreacion, Date fechaResolucion) {
        this.id = id;
        this.idEmpleado = idEmpleado;
        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.estado = estado;
        this.fechaCreacion = fechaCreacion;
        this.fechaResolucion = fechaResolucion;
    }

    // Constructor para inserción sin ID
    public Incidencia(int idEmpleado, String descripcion, String prioridad, String estado, Date fechaCreacion) {
        this.idEmpleado = idEmpleado;
        this.descripcion = descripcion;
        this.prioridad = prioridad;
        this.estado = estado;
        this.fechaCreacion = fechaCreacion;
    }

    // Getters y setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(String prioridad) {
        this.prioridad = prioridad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public Date getFechaResolucion() {
        return fechaResolucion;
    }

    public void setFechaResolucion(Date fechaResolucion) {
        this.fechaResolucion = fechaResolucion;
    }
}
